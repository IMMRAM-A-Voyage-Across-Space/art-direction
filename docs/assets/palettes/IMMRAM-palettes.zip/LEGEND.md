# Procreate palettes

The locked palette, cut into Procreate swatch sets. Generated from the
same table the sprite validator enforces, so these cannot drift from
[the palette](https://immram-a-voyage-across-space.github.io/art-direction/palette/).

## Download

**[Everything in one zip](IMMRAM-palettes.zip)** — or one at a time:

- [IMMRAM 0 · Universal](IMMRAM-0-Universal.swatches) — 25 swatches
- [IMMRAM 1 · Tech Duinn · Cnámh](IMMRAM-1-Cnamh.swatches) — 22 swatches
- [IMMRAM 2 · Gorias · Meirg](IMMRAM-2-Meirg.swatches) — 23 swatches
- [IMMRAM 3 · Murias · Oighear](IMMRAM-3-Oighear.swatches) — 22 swatches
- [IMMRAM 4 · Mag Mell · Machaire](IMMRAM-4-Machaire.swatches) — 24 swatches
- [IMMRAM 5 · Findias · Gríosach](IMMRAM-5-Griosach.swatches) — 23 swatches
- [IMMRAM 6 · Tír na nÓg · Draíocht](IMMRAM-6-Draiocht.swatches) — 23 swatches
- [IMMRAM 7 · Faction banners](IMMRAM-7-Faction-Banners.swatches) — 12 swatches
- [IMMRAM 8 · Liquids](IMMRAM-8-Liquids.swatches) — 18 swatches

## Importing on the iPad

1. Get the files onto the iPad — AirDrop, email attachment, or iCloud
   Drive. From the zip, tap it in **Files** first to unpack it.
2. Tap a `.swatches` file. Procreate opens and adds it under
   **Palettes**; repeat for each one.
3. In Procreate, open the colour panel → **Palettes** tab, and tap a
   palette's name to make it the active set.

## Which palette to paint from

**Universal** plus **the one world you are drawing** covers almost every
sprite — each world set already carries that world's two faction banners,
its liquid, and the shared Void / Shadow / Starlight / team rims, so you
rarely need to switch. The banner and liquid sets are for cross-checking
all twelve causes or all six liquids side by side.

## Legend

Procreate cannot store swatch *names*, so this is the key. Each grid is
five swatches per row, filled left to right, top to bottom — the tables
below are laid out exactly as the palette appears in the app.

### IMMRAM 0 · Universal

`IMMRAM-0-Universal.swatches` — 25 swatches

| Row | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|
| 1 | Void (outline)<br>`#08060f` | Shadow<br>`#14102a` | Starlight<br>`#e8ecff` | Illumination Gold<br>`#e8b83a` | Gold Glint<br>`#ffdf8a` |
| 2 | FX Blood<br>`#a01020` | FX Poison<br>`#7dff3d` | FX Fire<br>`#ff7a1f` | FX Frost<br>`#8fe6ff` | FX Shock<br>`#ffe14f` |
| 3 | FX Heal<br>`#3dff88` | FX Shield<br>`#4f9cff` | FX Smoke<br>`#6a6472` | Player rim (Ion Cyan)<br>`#4ff2ff` | Enemy rim (Magenta)<br>`#ff4fd8` |
| 4 | Wild / neutral<br>`#c7bca8` | UI Health<br>`#3dff88` | UI Low HP<br>`#ff3d4f` | UI Damage<br>`#ffffff` | UI Select<br>`#ffe14f` |
| 5 | Credits<br>`#ffd24f` | Alloy<br>`#b8c0d0` | Ore<br>`#c8763f` | Plasma<br>`#ff5ff0` | Crystal<br>`#6fe0ff` |

### IMMRAM 1 · Tech Duinn · Cnámh

`IMMRAM-1-Cnamh.swatches` — 22 swatches

| Row | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|
| 1 | Ramp Shade<br>`#241f2a` | Ramp Dark<br>`#4a453d` | Ramp Base<br>`#9a9082` | Ramp Light<br>`#ece2d0` | Ramp Hi<br>`#fbf6ec` |
| 2 | Crater<br>`#1a1620` | Rock<br>`#524d58` | Mineral<br>`#8fb0c0` | Hide<br>`#544a5a` | Carapace<br>`#8a8296` |
| 3 | Eye<br>`#6fd8ff` | Pop<br>`#ff5a5a` | Banner A<br>`#ffcf3a` | Banner B<br>`#6a4cff` | Liquid deep<br>`#14243a` |
| 4 | Liquid base<br>`#4a6a8a` | Liquid foam<br>`#9ab0c8` | Void (outline)<br>`#08060f` | Shadow<br>`#14102a` | Starlight<br>`#e8ecff` |
| 5 | Player rim<br>`#4ff2ff` | Enemy rim<br>`#ff4fd8` |  |  |  |

### IMMRAM 2 · Gorias · Meirg

`IMMRAM-2-Meirg.swatches` — 23 swatches

| Row | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|
| 1 | Ramp Shade<br>`#24100c` | Ramp Dark<br>`#5a2416` | Ramp Base<br>`#944228` | Ramp Light<br>`#c86842` | Ramp Hi<br>`#e89870` |
| 2 | Gunmetal<br>`#3a4250` | Pipe<br>`#5a6572` | Ember<br>`#ff7a3d` | Oil<br>`#14100a` | Hide<br>`#3a2a22` |
| 3 | Plate<br>`#6a5a4a` | Eye<br>`#ff8a3d` | Pop<br>`#4ee06a` | Banner A<br>`#ff3b30` | Banner B<br>`#33e6f0` |
| 4 | Liquid deep<br>`#163a12` | Liquid base<br>`#6ec828` | Liquid foam<br>`#c8ff6a` | Void (outline)<br>`#08060f` | Shadow<br>`#14102a` |
| 5 | Starlight<br>`#e8ecff` | Player rim<br>`#4ff2ff` | Enemy rim<br>`#ff4fd8` |  |  |

### IMMRAM 3 · Murias · Oighear

`IMMRAM-3-Oighear.swatches` — 22 swatches

| Row | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|
| 1 | Ramp Shade<br>`#101a3a` | Ramp Dark<br>`#2a5fa8` | Ramp Base<br>`#4f9ce0` | Ramp Light<br>`#a8e6ff` | Ramp Hi<br>`#e6f6ff` |
| 2 | Snow<br>`#eef6ff` | Deep ice<br>`#1f4a7a` | Rock<br>`#3a4250` | Hide<br>`#6a7a94` | Frost-skin<br>`#aebfd4` |
| 3 | Eye<br>`#a8f6ff` | Pop<br>`#ff6ad8` | Banner A<br>`#2e8bff` | Banner B<br>`#ff8a1e` | Liquid deep<br>`#0a3230` |
| 4 | Liquid base<br>`#22b8a8` | Liquid foam<br>`#a8f0e4` | Void (outline)<br>`#08060f` | Shadow<br>`#14102a` | Starlight<br>`#e8ecff` |
| 5 | Player rim<br>`#4ff2ff` | Enemy rim<br>`#ff4fd8` |  |  |  |

### IMMRAM 4 · Mag Mell · Machaire

`IMMRAM-4-Machaire.swatches` — 24 swatches

| Row | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|
| 1 | Ramp Shade<br>`#0a2a2a` | Ramp Dark<br>`#0f7a45` | Ramp Base<br>`#22c874` | Ramp Light<br>`#4dff9e` | Ramp Hi<br>`#c0ffe0` |
| 2 | Wood<br>`#6e4428` | Bark<br>`#3a2416` | Water<br>`#2f7ac0` | Soil<br>`#4a3420` | Rock<br>`#5a5a52` |
| 3 | Hide<br>`#3a4a22` | Moss<br>`#6a8a3a` | Eye<br>`#ffe14f` | Pop<br>`#5f82ff` | Banner A<br>`#1fbf5f` |
| 4 | Banner B<br>`#ff3ec9` | Liquid deep<br>`#0a2a4a` | Liquid base<br>`#2f7ac0` | Liquid foam<br>`#9fd4f0` | Void (outline)<br>`#08060f` |
| 5 | Shadow<br>`#14102a` | Starlight<br>`#e8ecff` | Player rim<br>`#4ff2ff` | Enemy rim<br>`#ff4fd8` |  |

### IMMRAM 5 · Findias · Gríosach

`IMMRAM-5-Griosach.swatches` — 23 swatches

| Row | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|
| 1 | Ramp Shade<br>`#2a0c08` | Ramp Dark<br>`#9c2408` | Ramp Base<br>`#e04810` | Ramp Light<br>`#ff6a2a` | Ramp Hi<br>`#ffb070` |
| 2 | Obsidian<br>`#120a10` | Ash<br>`#4a4550` | Char<br>`#2a1c1c` | Ember<br>`#ff9a4f` | Char-hide<br>`#3a1c16` |
| 3 | Cracked<br>`#7a2a1a` | Eye<br>`#ff5a2a` | Pop<br>`#2ad6ff` | Banner A<br>`#b6f53a` | Banner B<br>`#a94ce6` |
| 4 | Liquid deep<br>`#3a0c04` | Liquid base<br>`#ff5a14` | Liquid foam<br>`#ffd24a` | Void (outline)<br>`#08060f` | Shadow<br>`#14102a` |
| 5 | Starlight<br>`#e8ecff` | Player rim<br>`#4ff2ff` | Enemy rim<br>`#ff4fd8` |  |  |

### IMMRAM 6 · Tír na nÓg · Draíocht

`IMMRAM-6-Draiocht.swatches` — 23 swatches

| Row | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|
| 1 | Ramp Shade<br>`#1f0a3a` | Ramp Dark<br>`#6a1fa8` | Ramp Base<br>`#b03fe0` | Ramp Light<br>`#f06aff` | Ramp Hi<br>`#ffc0ff` |
| 2 | Spore<br>`#ff9fe0` | Bio-cyan<br>`#4ff2d0` | Flesh<br>`#d66a9c` | Rot<br>`#5a4a2a` | Creature flesh<br>`#7a3a8a` |
| 3 | Membrane<br>`#c86ad0` | Eye<br>`#a8ff3d` | Pop<br>`#ffe24a` | Banner A<br>`#1fd6a8` | Banner B<br>`#ff6f8f` |
| 4 | Liquid deep<br>`#0a2e3a` | Liquid base<br>`#2ad0c8` | Liquid foam<br>`#9ff0e8` | Void (outline)<br>`#08060f` | Shadow<br>`#14102a` |
| 5 | Starlight<br>`#e8ecff` | Player rim<br>`#4ff2ff` | Enemy rim<br>`#ff4fd8` |  |  |

### IMMRAM 7 · Faction banners

`IMMRAM-7-Faction-Banners.swatches` — 12 swatches

| Row | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|
| 1 | Cnámh A<br>`#ffcf3a` | Cnámh B<br>`#6a4cff` | Meirg A<br>`#ff3b30` | Meirg B<br>`#33e6f0` | Oighear A<br>`#2e8bff` |
| 2 | Oighear B<br>`#ff8a1e` | Machaire A<br>`#1fbf5f` | Machaire B<br>`#ff3ec9` | Gríosach A<br>`#b6f53a` | Gríosach B<br>`#a94ce6` |
| 3 | Draíocht A<br>`#1fd6a8` | Draíocht B<br>`#ff6f8f` |  |  |  |

### IMMRAM 8 · Liquids

`IMMRAM-8-Liquids.swatches` — 18 swatches

| Row | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|
| 1 | Cnámh water deep<br>`#14243a` | Cnámh water base<br>`#4a6a8a` | Cnámh water foam<br>`#9ab0c8` | Meirg acid deep<br>`#163a12` | Meirg acid base<br>`#6ec828` |
| 2 | Meirg acid foam<br>`#c8ff6a` | Oighear methane deep<br>`#0a3230` | Oighear methane base<br>`#22b8a8` | Oighear methane foam<br>`#a8f0e4` | Machaire water deep<br>`#0a2a4a` |
| 3 | Machaire water base<br>`#2f7ac0` | Machaire water foam<br>`#9fd4f0` | Gríosach lava deep<br>`#3a0c04` | Gríosach lava base<br>`#ff5a14` | Gríosach lava foam<br>`#ffd24a` |
| 4 | Draíocht water deep<br>`#0a2e3a` | Draíocht water base<br>`#2ad0c8` | Draíocht water foam<br>`#9ff0e8` |  |  |
