# Pixaki palettes

The locked palette, cut into Pixaki palettes. Generated from the same
table the sprite validator enforces, so these cannot drift from
[the palette](https://immram-a-voyage-across-space.github.io/art-direction/palette/). They are the same nine sets as the
[Procreate palettes](palette-procreate.md), in the same order.

## Download

**[Everything in one zip](IMMRAM-palettes-pixaki.zip)** — or one at
a time. Try `.gpl` first; `.aco` is there in case Pixaki dislikes it.

| Palette | Colours | GIMP | Photoshop |
|---|---|---|---|
| IMMRAM 0 · Universal | 25 | [`.gpl`](IMMRAM-0-Universal.gpl) | [`.aco`](IMMRAM-0-Universal.aco) |
| IMMRAM 1 · Tech Duinn · Cnámh | 22 | [`.gpl`](IMMRAM-1-Cnamh.gpl) | [`.aco`](IMMRAM-1-Cnamh.aco) |
| IMMRAM 2 · Gorias · Meirg | 23 | [`.gpl`](IMMRAM-2-Meirg.gpl) | [`.aco`](IMMRAM-2-Meirg.aco) |
| IMMRAM 3 · Murias · Oighear | 22 | [`.gpl`](IMMRAM-3-Oighear.gpl) | [`.aco`](IMMRAM-3-Oighear.aco) |
| IMMRAM 4 · Mag Mell · Machaire | 24 | [`.gpl`](IMMRAM-4-Machaire.gpl) | [`.aco`](IMMRAM-4-Machaire.aco) |
| IMMRAM 5 · Findias · Gríosach | 23 | [`.gpl`](IMMRAM-5-Griosach.gpl) | [`.aco`](IMMRAM-5-Griosach.aco) |
| IMMRAM 6 · Tír na nÓg · Draíocht | 23 | [`.gpl`](IMMRAM-6-Draiocht.gpl) | [`.aco`](IMMRAM-6-Draiocht.aco) |
| IMMRAM 7 · Faction banners | 12 | [`.gpl`](IMMRAM-7-Faction-Banners.gpl) | [`.aco`](IMMRAM-7-Faction-Banners.aco) |
| IMMRAM 8 · Liquids | 18 | [`.gpl`](IMMRAM-8-Liquids.gpl) | [`.aco`](IMMRAM-8-Liquids.aco) |

## Importing on the iPad

1. Get the files onto the iPad — AirDrop, email attachment, or iCloud
   Drive. From the zip, tap it in **Files** first to unpack it.
2. In Pixaki, open the palette panel and tap the more options button →
   **Load palette**.
3. Choose **Import**, pick where the file is, and select it. Repeat for
   each palette you want.

Unlike Procreate, Pixaki keeps the name on every swatch, so you can check
what a colour is without coming back to this page.

## Which palette to paint from

**Universal** plus **the one world you are drawing** covers almost every
sprite — each world set already carries that world's two faction banners,
its liquid, and the shared Void / Shadow / Starlight / team rims, so you
rarely need to switch. The banner and liquid sets are for cross-checking
all twelve causes or all six liquids side by side.

## Legend

Pixaki chooses its own grid to suit the panel width, so this is a flat
list in palette order rather than a map of the layout.

### IMMRAM 0 · Universal

`IMMRAM-0-Universal.gpl` / `IMMRAM-0-Universal.aco` — 25 colours

1. Void (outline) — `#08060f`
2. Shadow — `#14102a`
3. Starlight — `#e8ecff`
4. Illumination Gold — `#e8b83a`
5. Gold Glint — `#ffdf8a`
6. FX Blood — `#a01020`
7. FX Poison — `#7dff3d`
8. FX Fire — `#ff7a1f`
9. FX Frost — `#8fe6ff`
10. FX Shock — `#ffe14f`
11. FX Heal — `#3dff88`
12. FX Shield — `#4f9cff`
13. FX Smoke — `#6a6472`
14. Player rim (Ion Cyan) — `#4ff2ff`
15. Enemy rim (Magenta) — `#ff4fd8`
16. Wild / neutral — `#c7bca8`
17. UI Health — `#3dff88`
18. UI Low HP — `#ff3d4f`
19. UI Damage — `#ffffff`
20. UI Select — `#ffe14f`
21. Credits — `#ffd24f`
22. Alloy — `#b8c0d0`
23. Ore — `#c8763f`
24. Plasma — `#ff5ff0`
25. Crystal — `#6fe0ff`

### IMMRAM 1 · Tech Duinn · Cnámh

`IMMRAM-1-Cnamh.gpl` / `IMMRAM-1-Cnamh.aco` — 22 colours

1. Ramp Shade — `#241f2a`
2. Ramp Dark — `#4a453d`
3. Ramp Base — `#9a9082`
4. Ramp Light — `#ece2d0`
5. Ramp Hi — `#fbf6ec`
6. Crater — `#1a1620`
7. Rock — `#524d58`
8. Mineral — `#8fb0c0`
9. Hide — `#544a5a`
10. Carapace — `#8a8296`
11. Eye — `#6fd8ff`
12. Pop — `#ff5a5a`
13. Banner A — `#ffcf3a`
14. Banner B — `#6a4cff`
15. Liquid deep — `#14243a`
16. Liquid base — `#4a6a8a`
17. Liquid foam — `#9ab0c8`
18. Void (outline) — `#08060f`
19. Shadow — `#14102a`
20. Starlight — `#e8ecff`
21. Player rim — `#4ff2ff`
22. Enemy rim — `#ff4fd8`

### IMMRAM 2 · Gorias · Meirg

`IMMRAM-2-Meirg.gpl` / `IMMRAM-2-Meirg.aco` — 23 colours

1. Ramp Shade — `#24100c`
2. Ramp Dark — `#5a2416`
3. Ramp Base — `#944228`
4. Ramp Light — `#c86842`
5. Ramp Hi — `#e89870`
6. Gunmetal — `#3a4250`
7. Pipe — `#5a6572`
8. Ember — `#ff7a3d`
9. Oil — `#14100a`
10. Hide — `#3a2a22`
11. Plate — `#6a5a4a`
12. Eye — `#ff8a3d`
13. Pop — `#4ee06a`
14. Banner A — `#ff3b30`
15. Banner B — `#33e6f0`
16. Liquid deep — `#163a12`
17. Liquid base — `#6ec828`
18. Liquid foam — `#c8ff6a`
19. Void (outline) — `#08060f`
20. Shadow — `#14102a`
21. Starlight — `#e8ecff`
22. Player rim — `#4ff2ff`
23. Enemy rim — `#ff4fd8`

### IMMRAM 3 · Murias · Oighear

`IMMRAM-3-Oighear.gpl` / `IMMRAM-3-Oighear.aco` — 22 colours

1. Ramp Shade — `#101a3a`
2. Ramp Dark — `#2a5fa8`
3. Ramp Base — `#4f9ce0`
4. Ramp Light — `#a8e6ff`
5. Ramp Hi — `#e6f6ff`
6. Snow — `#eef6ff`
7. Deep ice — `#1f4a7a`
8. Rock — `#3a4250`
9. Hide — `#6a7a94`
10. Frost-skin — `#aebfd4`
11. Eye — `#a8f6ff`
12. Pop — `#ff6ad8`
13. Banner A — `#2e8bff`
14. Banner B — `#ff8a1e`
15. Liquid deep — `#0a3230`
16. Liquid base — `#22b8a8`
17. Liquid foam — `#a8f0e4`
18. Void (outline) — `#08060f`
19. Shadow — `#14102a`
20. Starlight — `#e8ecff`
21. Player rim — `#4ff2ff`
22. Enemy rim — `#ff4fd8`

### IMMRAM 4 · Mag Mell · Machaire

`IMMRAM-4-Machaire.gpl` / `IMMRAM-4-Machaire.aco` — 24 colours

1. Ramp Shade — `#0a2a2a`
2. Ramp Dark — `#0f7a45`
3. Ramp Base — `#22c874`
4. Ramp Light — `#4dff9e`
5. Ramp Hi — `#c0ffe0`
6. Wood — `#6e4428`
7. Bark — `#3a2416`
8. Water — `#2f7ac0`
9. Soil — `#4a3420`
10. Rock — `#5a5a52`
11. Hide — `#3a4a22`
12. Moss — `#6a8a3a`
13. Eye — `#ffe14f`
14. Pop — `#5f82ff`
15. Banner A — `#1fbf5f`
16. Banner B — `#ff3ec9`
17. Liquid deep — `#0a2a4a`
18. Liquid base — `#2f7ac0`
19. Liquid foam — `#9fd4f0`
20. Void (outline) — `#08060f`
21. Shadow — `#14102a`
22. Starlight — `#e8ecff`
23. Player rim — `#4ff2ff`
24. Enemy rim — `#ff4fd8`

### IMMRAM 5 · Findias · Gríosach

`IMMRAM-5-Griosach.gpl` / `IMMRAM-5-Griosach.aco` — 23 colours

1. Ramp Shade — `#2a0c08`
2. Ramp Dark — `#9c2408`
3. Ramp Base — `#e04810`
4. Ramp Light — `#ff6a2a`
5. Ramp Hi — `#ffb070`
6. Obsidian — `#120a10`
7. Ash — `#4a4550`
8. Char — `#2a1c1c`
9. Ember — `#ff9a4f`
10. Char-hide — `#3a1c16`
11. Cracked — `#7a2a1a`
12. Eye — `#ff5a2a`
13. Pop — `#2ad6ff`
14. Banner A — `#b6f53a`
15. Banner B — `#a94ce6`
16. Liquid deep — `#3a0c04`
17. Liquid base — `#ff5a14`
18. Liquid foam — `#ffd24a`
19. Void (outline) — `#08060f`
20. Shadow — `#14102a`
21. Starlight — `#e8ecff`
22. Player rim — `#4ff2ff`
23. Enemy rim — `#ff4fd8`

### IMMRAM 6 · Tír na nÓg · Draíocht

`IMMRAM-6-Draiocht.gpl` / `IMMRAM-6-Draiocht.aco` — 23 colours

1. Ramp Shade — `#1f0a3a`
2. Ramp Dark — `#6a1fa8`
3. Ramp Base — `#b03fe0`
4. Ramp Light — `#f06aff`
5. Ramp Hi — `#ffc0ff`
6. Spore — `#ff9fe0`
7. Bio-cyan — `#4ff2d0`
8. Flesh — `#d66a9c`
9. Rot — `#5a4a2a`
10. Creature flesh — `#7a3a8a`
11. Membrane — `#c86ad0`
12. Eye — `#a8ff3d`
13. Pop — `#ffe24a`
14. Banner A — `#1fd6a8`
15. Banner B — `#ff6f8f`
16. Liquid deep — `#0a2e3a`
17. Liquid base — `#2ad0c8`
18. Liquid foam — `#9ff0e8`
19. Void (outline) — `#08060f`
20. Shadow — `#14102a`
21. Starlight — `#e8ecff`
22. Player rim — `#4ff2ff`
23. Enemy rim — `#ff4fd8`

### IMMRAM 7 · Faction banners

`IMMRAM-7-Faction-Banners.gpl` / `IMMRAM-7-Faction-Banners.aco` — 12 colours

1. Cnámh A — `#ffcf3a`
2. Cnámh B — `#6a4cff`
3. Meirg A — `#ff3b30`
4. Meirg B — `#33e6f0`
5. Oighear A — `#2e8bff`
6. Oighear B — `#ff8a1e`
7. Machaire A — `#1fbf5f`
8. Machaire B — `#ff3ec9`
9. Gríosach A — `#b6f53a`
10. Gríosach B — `#a94ce6`
11. Draíocht A — `#1fd6a8`
12. Draíocht B — `#ff6f8f`

### IMMRAM 8 · Liquids

`IMMRAM-8-Liquids.gpl` / `IMMRAM-8-Liquids.aco` — 18 colours

1. Cnámh water deep — `#14243a`
2. Cnámh water base — `#4a6a8a`
3. Cnámh water foam — `#9ab0c8`
4. Meirg acid deep — `#163a12`
5. Meirg acid base — `#6ec828`
6. Meirg acid foam — `#c8ff6a`
7. Oighear methane deep — `#0a3230`
8. Oighear methane base — `#22b8a8`
9. Oighear methane foam — `#a8f0e4`
10. Machaire water deep — `#0a2a4a`
11. Machaire water base — `#2f7ac0`
12. Machaire water foam — `#9fd4f0`
13. Gríosach lava deep — `#3a0c04`
14. Gríosach lava base — `#ff5a14`
15. Gríosach lava foam — `#ffd24a`
16. Draíocht water deep — `#0a2e3a`
17. Draíocht water base — `#2ad0c8`
18. Draíocht water foam — `#9ff0e8`
